import express from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import { INITIAL_GAMES } from './src/data/initialGames';
import { GameProject } from './src/types';

const app = express();
const PORT = 3000;

// Enable JSON parsing
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

// Directories
const DATA_DIR = path.join(process.cwd(), 'data');
const GAMES_FILE = path.join(DATA_DIR, 'games.json');
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
const BUILDS_DIR = path.join(UPLOADS_DIR, 'builds');

// Ensure directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
if (!fs.existsSync(BUILDS_DIR)) {
  fs.mkdirSync(BUILDS_DIR, { recursive: true });
}

// Helper: Read games from file storage or initialize with defaults
function getStoredGames(): GameProject[] {
  try {
    if (fs.existsSync(GAMES_FILE)) {
      const data = fs.readFileSync(GAMES_FILE, 'utf-8');
      const games = JSON.parse(data);
      if (Array.isArray(games) && games.length > 0) {
        return games;
      }
    }
  } catch (err) {
    console.error('Error reading games.json, falling back to initial data:', err);
  }

  // Save initial games to storage
  saveStoredGames(INITIAL_GAMES);
  return INITIAL_GAMES;
}

// Helper: Save games to file storage
function saveStoredGames(games: GameProject[]) {
  try {
    fs.writeFileSync(GAMES_FILE, JSON.stringify(games, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving games.json:', err);
  }
}

// Helper: Seed dummy zip build files so initial projects are instantly downloadable
function seedSampleBuildFiles() {
  const sampleBuilds = [
    { name: 'AetherRift_v1.3.0_Win64.zip', text: 'Unity Build Archive: Aether Rift Windows 64-bit Edition v1.3.0\nExecutable: AetherRift.exe' },
    { name: 'AetherRift_v1.3.0_macOS.zip', text: 'Unity Build Archive: Aether Rift macOS Apple Silicon Edition v1.3.0\nApp: AetherRift.app' },
    { name: 'AetherRift_v1.3.0_Linux.AppImage', text: 'Unity Build Archive: Aether Rift Linux Executable v1.3.0' },
    { name: 'Eldoria_Demo_v0.8.2_Win.zip', text: 'Unity Build Archive: Chronicles of Eldoria Windows Demo v0.8.2' },
    { name: 'Eldoria_Demo_v0.8.2_Mac.zip', text: 'Unity Build Archive: Chronicles of Eldoria macOS Demo v0.8.2' },
    { name: 'NeonVelocity_WebGL_v2.0.0.zip', text: 'Unity WebGL Build Package: Neon Velocity Browser Version' },
    { name: 'NeonVelocity_v2.0.0.apk', text: 'Unity Android APK Package: Neon Velocity v2.0.0' },
    { name: 'NeonVelocity_v2.0.0_Win64.zip', text: 'Unity Build Archive: Neon Velocity Windows Standalone' },
    { name: 'AstralEchoes_v1.1.0_Win64.zip', text: 'Unity Build Archive: Astral Echoes Windows Edition' },
    { name: 'AstralEchoes_v1.1.0_Mac.zip', text: 'Unity Build Archive: Astral Echoes macOS Universal Build' }
  ];

  sampleBuilds.forEach((build) => {
    const filePath = path.join(BUILDS_DIR, build.name);
    if (!fs.existsSync(filePath)) {
      // Create a small text dummy file simulating a zip archive
      const content = Buffer.from(`PK\x03\x04 Unity Game Build Package: ${build.name}\n${build.text}\nCreated for Unity Developer Portfolio Showcase.`);
      fs.writeFileSync(filePath, content);
    }
  });
}

// Seed build files on server boot
seedSampleBuildFiles();

// Multer Storage Configuration for File Uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    if (file.fieldname === 'buildFile') {
      cb(null, BUILDS_DIR);
    } else {
      cb(null, UPLOADS_DIR);
    }
  },
  filename: (req, file, cb) => {
    const cleanName = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, `${uniqueSuffix}-${cleanName}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024 } // 500MB max limit per file
});

// Serve uploads directory publicly for browser preview and direct downloads
app.use('/uploads', express.static(UPLOADS_DIR, {
  setHeaders: (res, filePath) => {
    // If it's a build file, set attachment download header
    if (filePath.includes('/builds/') || filePath.endsWith('.zip') || filePath.endsWith('.apk') || filePath.endsWith('.exe') || filePath.endsWith('.AppImage')) {
      const fileName = path.basename(filePath);
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
    }
  }
}));

// API Routes

// 1. Get all game projects
app.get('/api/games', (req, res) => {
  const games = getStoredGames();
  res.json(games);
});

// 2. Get single game project by ID
app.get('/api/games/:id', (req, res) => {
  const games = getStoredGames();
  const game = games.find((g) => g.id === req.params.id);
  if (!game) {
    return res.status(404).json({ error: 'Game project not found' });
  }
  res.json(game);
});

// 3. Create a new game project
app.post('/api/games', (req, res) => {
  const games = getStoredGames();
  const newGame: GameProject = req.body;

  if (!newGame.id || !newGame.title) {
    return res.status(400).json({ error: 'Title and ID are required' });
  }

  // Check duplicate ID
  if (games.some((g) => g.id === newGame.id)) {
    newGame.id = newGame.id + '-' + Date.now();
  }

  // Set default counters
  newGame.downloadsCount = newGame.downloadsCount || 0;
  newGame.likesCount = newGame.likesCount || 0;
  newGame.reviews = newGame.reviews || [];
  newGame.devlogs = newGame.devlogs || [];
  newGame.builds = newGame.builds || [];
  newGame.screenshots = newGame.screenshots || [];
  newGame.technicalHighlights = newGame.technicalHighlights || [];

  games.unshift(newGame);
  saveStoredGames(games);

  res.status(201).json({ message: 'Game project created successfully', game: newGame });
});

// 4. Update an existing game project
app.put('/api/games/:id', (req, res) => {
  const games = getStoredGames();
  const index = games.findIndex((g) => g.id === req.params.id);

  if (index === -1) {
    return res.status(404).json({ error: 'Game project not found' });
  }

  const updatedGame: GameProject = {
    ...games[index],
    ...req.body
  };

  games[index] = updatedGame;
  saveStoredGames(games);

  res.json({ message: 'Game project updated successfully', game: updatedGame });
});

// 5. Delete a game project
app.delete('/api/games/:id', (req, res) => {
  let games = getStoredGames();
  const exists = games.some((g) => g.id === req.params.id);

  if (!exists) {
    return res.status(404).json({ error: 'Game project not found' });
  }

  games = games.filter((g) => g.id !== req.params.id);
  saveStoredGames(games);

  res.json({ message: 'Game project deleted successfully' });
});

// 6. Record build download & increment count
app.post('/api/games/:id/download/:buildId', (req, res) => {
  const games = getStoredGames();
  const game = games.find((g) => g.id === req.params.id);

  if (!game) {
    return res.status(404).json({ error: 'Game project not found' });
  }

  game.downloadsCount = (game.downloadsCount || 0) + 1;

  if (game.builds) {
    const build = game.builds.find((b) => b.id === req.params.buildId);
    if (build) {
      build.downloadCount = (build.downloadCount || 0) + 1;
    }
  }

  saveStoredGames(games);
  res.json({ success: true, downloadsCount: game.downloadsCount });
});

// 7. Like a game
app.post('/api/games/:id/like', (req, res) => {
  const games = getStoredGames();
  const game = games.find((g) => g.id === req.params.id);

  if (!game) {
    return res.status(404).json({ error: 'Game project not found' });
  }

  game.likesCount = (game.likesCount || 0) + 1;
  saveStoredGames(games);

  res.json({ success: true, likesCount: game.likesCount });
});

// 8. Add review
app.post('/api/games/:id/reviews', (req, res) => {
  const games = getStoredGames();
  const game = games.find((g) => g.id === req.params.id);

  if (!game) {
    return res.status(404).json({ error: 'Game project not found' });
  }

  const { author, rating, comment } = req.body;
  if (!author || !rating || !comment) {
    return res.status(400).json({ error: 'Author, rating, and comment are required' });
  }

  const newReview = {
    id: 'rev-' + Date.now(),
    author: String(author).trim(),
    rating: Number(rating) || 5,
    date: new Date().toISOString().split('T')[0],
    comment: String(comment).trim()
  };

  game.reviews = game.reviews || [];
  game.reviews.unshift(newReview);
  saveStoredGames(games);

  res.json({ success: true, review: newReview, reviews: game.reviews });
});

// 9. Upload File Endpoint (Builds, Cover Images, Screenshots, Videos)
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  const isBuild = req.body.isBuild === 'true' || req.file.fieldname === 'buildFile';
  const subFolder = isBuild ? 'builds' : '';
  const fileUrl = `/uploads/${subFolder ? subFolder + '/' : ''}${req.file.filename}`;

  const fileSizeMB = (req.file.size / (1024 * 1024)).toFixed(1) + ' MB';

  res.json({
    success: true,
    fileUrl,
    fileName: req.file.originalname,
    storedName: req.file.filename,
    fileSize: fileSizeMB,
    mimeType: req.file.mimetype
  });
});

// Vite Middleware for Development and Static Express Serving in Production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Unity Developer Portfolio Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
