import React, { useState } from 'react';
import { GameProject, GameBuild, PlatformType, GameStatus } from '../types';
import { 
  X, Plus, Upload, Trash2, Edit3, Save, Sparkles, Check, 
  FileArchive, Monitor, Video, Image, Terminal, ShieldAlert 
} from 'lucide-react';

interface AdminCMSModalProps {
  games: GameProject[];
  onClose: () => void;
  onSaveGame: (game: GameProject, isNew: boolean) => Promise<void>;
  onDeleteGame: (gameId: string) => Promise<void>;
}

export const AdminCMSModal: React.FC<AdminCMSModalProps> = ({
  games,
  onClose,
  onSaveGame,
  onDeleteGame
}) => {
  const [editingGameId, setEditingGameId] = useState<string | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgressMsg, setUploadProgressMsg] = useState('');

  // Form Fields State
  const [formData, setFormData] = useState<Partial<GameProject>>({
    id: '',
    title: '',
    tagline: '',
    description: '',
    detailedOverview: '',
    coverImage: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80',
    unityVersion: 'Unity 6 (6000.0.1f1)',
    renderPipeline: 'URP',
    genre: ['Action', '3D'],
    status: 'Released',
    releaseDate: new Date().toISOString().split('T')[0],
    featured: false,
    developerNotes: '',
    trailerUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    screenshots: [
      'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80'
    ],
    builds: [],
    technicalHighlights: ['Custom Unity URP Shaders', 'C# Job System Integration'],
    minRequirements: {
      os: 'Windows 10 64-bit',
      processor: 'Quad-core 2.5 GHz',
      memory: '8 GB RAM',
      graphics: 'GTX 1060 or equivalent',
      storage: '1 GB space'
    },
    devlogs: []
  });

  // Build entry inline form state
  const [newBuildPlatform, setNewBuildPlatform] = useState<PlatformType>('windows');
  const [newBuildTitle, setNewBuildTitle] = useState('Windows Standalone Build');
  const [newBuildFileUrl, setNewBuildFileUrl] = useState('');
  const [newBuildFileName, setNewBuildFileName] = useState('MyGame_v1.0.0_Win64.zip');
  const [newBuildFileSize, setNewBuildFileSize] = useState('45.0 MB');
  const [newBuildVersion, setNewBuildVersion] = useState('1.0.0');

  // Load existing game into form
  const handleSelectGameToEdit = (game: GameProject) => {
    setIsCreatingNew(false);
    setEditingGameId(game.id);
    setFormData({ ...game });
  };

  // Switch to blank new game form
  const handleStartCreateNew = () => {
    setIsCreatingNew(true);
    setEditingGameId(null);
    const newId = 'game-' + Date.now();
    setFormData({
      id: newId,
      title: 'New Unity Project',
      tagline: 'Short tagline introducing the mechanics or theme.',
      description: 'Full summary of gameplay, engine optimizations, and aesthetic style.',
      detailedOverview: 'Detailed breakdown of C# script architecture, custom shaders, and asset pipelines used in Unity.',
      coverImage: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80',
      unityVersion: 'Unity 6 (6000.0)',
      renderPipeline: 'URP',
      genre: ['Action', '3D', 'Physics'],
      status: 'In Development',
      releaseDate: new Date().toISOString().split('T')[0],
      featured: false,
      trailerUrl: '',
      screenshots: [
        'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=1200&q=80'
      ],
      builds: [],
      technicalHighlights: ['Unity 6 URP Pipeline', 'C# Burst Compiler Jobs'],
      devlogs: [],
      downloadsCount: 0,
      likesCount: 0,
      reviews: []
    });
  };

  // Upload file handler to Express /api/upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, targetField: 'cover' | 'screenshot' | 'build') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setUploadProgressMsg(`Uploading ${file.name}...`);

    try {
      const uploadFormData = new FormData();
      uploadFormData.append('file', file);
      if (targetField === 'build') {
        uploadFormData.append('isBuild', 'true');
      }

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: uploadFormData
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed');

      if (targetField === 'cover') {
        setFormData((prev) => ({ ...prev, coverImage: data.fileUrl }));
      } else if (targetField === 'screenshot') {
        setFormData((prev) => ({
          ...prev,
          screenshots: [...(prev.screenshots || []), data.fileUrl]
        }));
      } else if (targetField === 'build') {
        setNewBuildFileUrl(data.fileUrl);
        setNewBuildFileName(data.fileName);
        setNewBuildFileSize(data.fileSize);
      }

      setUploadProgressMsg('File uploaded successfully!');
      setTimeout(() => setUploadProgressMsg(''), 3000);
    } catch (err: any) {
      alert(`File upload failed: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  // Add Build to list
  const handleAddBuild = () => {
    if (!newBuildFileUrl) {
      alert('Please select or upload a build file URL first.');
      return;
    }
    const newBuildObj: GameBuild = {
      id: 'build-' + Date.now(),
      platform: newBuildPlatform,
      title: newBuildTitle,
      fileName: newBuildFileName,
      fileUrl: newBuildFileUrl,
      fileSize: newBuildFileSize,
      version: newBuildVersion,
      releaseDate: new Date().toISOString().split('T')[0],
      downloadCount: 0
    };

    setFormData((prev) => ({
      ...prev,
      builds: [...(prev.builds || []), newBuildObj]
    }));

    // Reset inline build inputs
    setNewBuildFileUrl('');
    setNewBuildFileName('MyGame_Build.zip');
  };

  const handleRemoveBuild = (buildId: string) => {
    setFormData((prev) => ({
      ...prev,
      builds: (prev.builds || []).filter((b) => b.id !== buildId)
    }));
  };

  // Save Game Form Submit
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.id) return;

    setSaving(true);
    await onSaveGame(formData as GameProject, isCreatingNew);
    setSaving(false);
    onClose();
  };

  // Delete Game
  const handleDelete = async (gameId: string) => {
    if (confirm('Are you sure you want to delete this Unity project from your portfolio?')) {
      await onDeleteGame(gameId);
      if (editingGameId === gameId) {
        setIsCreatingNew(false);
        setEditingGameId(null);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#020204]/95 backdrop-blur-xl animate-fadeIn">
      <div className="relative w-full max-w-5xl h-[90vh] bg-[#020204] border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="p-5 bg-white/[0.02] border-b border-white/10 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-mono uppercase tracking-widest font-extrabold text-white">Unity Studio CMS Dashboard</h2>
              <p className="text-xs text-slate-400 font-light">Add, update, or upload new game builds & media showcase</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          
          {/* Left Sidebar: Game Projects Selector */}
          <div className="w-full md:w-64 bg-black/60 border-r border-white/10 p-4 flex flex-col shrink-0 overflow-y-auto">
            <button
              onClick={handleStartCreateNew}
              className={`w-full py-2.5 px-3 rounded-xl border text-xs font-mono uppercase tracking-wider transition-all flex items-center justify-center gap-2 mb-4 cursor-pointer ${
                isCreatingNew
                  ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.4)] font-bold'
                  : 'bg-white/[0.03] hover:bg-white/[0.08] text-cyan-400 border-white/10'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>Upload New Game</span>
            </button>

            <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-slate-400 mb-2">
              Existing Projects ({games.length})
            </span>

            <div className="space-y-1.5 flex-1 overflow-y-auto">
              {games.map((g) => (
                <div
                  key={g.id}
                  onClick={() => handleSelectGameToEdit(g)}
                  className={`p-2.5 rounded-xl border text-xs transition-all cursor-pointer flex items-center justify-between group ${
                    editingGameId === g.id && !isCreatingNew
                      ? 'bg-white/[0.06] text-white border-cyan-500/50 shadow-sm'
                      : 'bg-white/[0.01] hover:bg-white/[0.04] text-slate-300 border-white/5'
                  }`}
                >
                  <div className="truncate mr-2">
                    <span className="font-mono font-bold block truncate uppercase">{g.title}</span>
                    <span className="text-[10px] text-slate-400 block font-mono">{g.unityVersion}</span>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(g.id);
                    }}
                    className="p-1 rounded text-slate-500 hover:text-rose-400 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Delete Project"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Right Form Area */}
          <div className="flex-1 p-6 overflow-y-auto bg-[#020204]">
            {editingGameId || isCreatingNew ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                
                <div className="flex items-center justify-between pb-4 border-b border-white/10">
                  <h3 className="text-xs font-mono uppercase tracking-widest font-extrabold text-white">
                    {isCreatingNew ? 'Create & Upload New Unity Project' : `Editing: ${formData.title}`}
                  </h3>
                  <button
                    type="submit"
                    disabled={saving || uploading}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-mono font-bold text-xs uppercase tracking-wider shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                  >
                    <Save className="w-4 h-4 text-slate-950" />
                    <span>{saving ? 'Saving Project...' : 'Save Game Project'}</span>
                  </button>
                </div>

                {uploadProgressMsg && (
                  <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/40 text-cyan-300 text-xs font-mono flex items-center gap-2">
                    <div className="w-3.5 h-3.5 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                    <span>{uploadProgressMsg}</span>
                  </div>
                )}

                {/* BASIC INFO */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">Game Title *</label>
                    <input
                      type="text"
                      required
                      value={formData.title || ''}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">Unity Version *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Unity 6 (6000.0) or 2022.3 LTS"
                      value={formData.unityVersion || ''}
                      onChange={(e) => setFormData({ ...formData, unityVersion: e.target.value })}
                      className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">Render Pipeline</label>
                    <select
                      value={formData.renderPipeline || 'URP'}
                      onChange={(e) => setFormData({ ...formData, renderPipeline: e.target.value as any })}
                      className="w-full px-3 py-2 bg-[#020204] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                    >
                      <option value="URP">Universal Render Pipeline (URP)</option>
                      <option value="HDRP">High Definition Render Pipeline (HDRP)</option>
                      <option value="Built-in">Built-in Pipeline</option>
                      <option value="Custom">Custom Shaders Pipeline</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">Development Status</label>
                    <select
                      value={formData.status || 'Released'}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                      className="w-full px-3 py-2 bg-[#020204] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                    >
                      <option value="Released">Released</option>
                      <option value="Playable Demo">Playable Demo</option>
                      <option value="Early Access">Early Access</option>
                      <option value="In Development">In Development</option>
                      <option value="Prototype">Prototype</option>
                    </select>
                  </div>
                </div>

                {/* TAGLINE & DESCRIPTION */}
                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1">Short Tagline</label>
                  <input
                    type="text"
                    value={formData.tagline || ''}
                    onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                    className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-mono text-slate-400 mb-1">Detailed Technical Overview</label>
                  <textarea
                    rows={4}
                    value={formData.detailedOverview || ''}
                    onChange={(e) => setFormData({ ...formData, detailedOverview: e.target.value })}
                    className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>

                {/* MEDIA & COVER IMAGE */}
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-3">
                  <h4 className="text-[10px] font-mono font-bold uppercase tracking-widest text-cyan-400 flex items-center gap-2">
                    <Image className="w-4 h-4" /> Cover Image & Screenshots
                  </h4>

                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">Cover Image URL / File Upload</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={formData.coverImage || ''}
                        onChange={(e) => setFormData({ ...formData, coverImage: e.target.value })}
                        className="flex-1 px-3 py-2 bg-white/[0.03] border border-white/10 rounded-xl text-xs text-white font-mono"
                      />
                      <label className="px-3 py-2 bg-white/[0.06] hover:bg-white/[0.1] text-white rounded-xl text-xs font-mono cursor-pointer flex items-center gap-1.5 shrink-0 border border-white/10">
                        <Upload className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Upload File</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleFileUpload(e, 'cover')}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">Gameplay Trailer YouTube Embed URL</label>
                    <input
                      type="text"
                      placeholder="e.g. https.youtube.com/embed/XXXXXX"
                      value={formData.trailerUrl || ''}
                      onChange={(e) => setFormData({ ...formData, trailerUrl: e.target.value })}
                      className="w-full px-3 py-2 bg-white/[0.03] border border-white/10 rounded-xl text-xs text-white font-mono"
                    />
                  </div>
                </div>

                {/* UPLOADABLE BUILD FILES MANAGEMENT */}
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-4">
                  <h4 className="text-[10px] font-mono font-bold uppercase tracking-widest text-cyan-400 flex items-center gap-2">
                    <FileArchive className="w-4 h-4" /> Downloadable Game Build Manager (.zip, .apk, .exe)
                  </h4>

                  {/* Existing Builds List */}
                  <div className="space-y-2">
                    {formData.builds && formData.builds.length > 0 ? (
                      formData.builds.map((b) => (
                        <div key={b.id} className="p-3 rounded-xl bg-[#020204] border border-white/10 flex items-center justify-between text-xs font-mono">
                          <div>
                            <span className="font-bold text-cyan-400 uppercase mr-2">[{b.platform}]</span>
                            <span className="text-slate-200 font-semibold">{b.title}</span>
                            <span className="text-slate-400 text-[10px] ml-2">({b.fileSize} • {b.fileName})</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveBuild(b.id)}
                            className="p-1 text-slate-500 hover:text-rose-400"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))
                    ) : (
                      <p className="text-xs font-mono text-slate-500 italic">No build files attached to this game yet.</p>
                    )}
                  </div>

                  {/* Inline Add Build Sub-Form */}
                  <div className="p-4 rounded-xl bg-[#020204] border border-white/10 space-y-3">
                    <span className="text-xs font-mono font-bold uppercase tracking-wider text-white block">Add / Upload New Build File</span>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <select
                        value={newBuildPlatform}
                        onChange={(e) => setNewBuildPlatform(e.target.value as PlatformType)}
                        className="px-2.5 py-2 bg-white/[0.03] border border-white/10 rounded-xl text-xs text-white font-mono"
                      >
                        <option value="windows">Windows (.exe / .zip)</option>
                        <option value="mac">macOS (.app / .zip)</option>
                        <option value="linux">Linux (.AppImage)</option>
                        <option value="webgl">WebGL Browser</option>
                        <option value="android">Android (.apk)</option>
                      </select>

                      <input
                        type="text"
                        placeholder="Build Title (e.g. Win64 v1.2)"
                        value={newBuildTitle}
                        onChange={(e) => setNewBuildTitle(e.target.value)}
                        className="px-2.5 py-2 bg-white/[0.03] border border-white/10 rounded-xl text-xs text-white font-mono"
                      />

                      <input
                        type="text"
                        placeholder="Version (e.g. 1.2.0)"
                        value={newBuildVersion}
                        onChange={(e) => setNewBuildVersion(e.target.value)}
                        className="px-2.5 py-2 bg-white/[0.03] border border-white/10 rounded-xl text-xs text-white font-mono"
                      />
                    </div>

                    {/* Upload Build File Trigger */}
                    <div className="flex gap-2 items-center">
                      <input
                        type="text"
                        placeholder="File URL or upload game archive"
                        value={newBuildFileUrl}
                        onChange={(e) => setNewBuildFileUrl(e.target.value)}
                        className="flex-1 px-3 py-2 bg-white/[0.03] border border-white/10 rounded-xl text-xs text-white font-mono"
                      />

                      <label className="px-3 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-xl text-xs font-mono font-extrabold cursor-pointer flex items-center gap-1 shrink-0 uppercase tracking-wider">
                        <Upload className="w-3.5 h-3.5 text-slate-950" />
                        <span>Upload .zip/.apk</span>
                        <input
                          type="file"
                          accept=".zip,.rar,.7z,.apk,.exe,.AppImage"
                          onChange={(e) => handleFileUpload(e, 'build')}
                          className="hidden"
                        />
                      </label>
                    </div>

                    <button
                      type="button"
                      onClick={handleAddBuild}
                      className="w-full py-2.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-cyan-300 border border-white/10 font-mono font-bold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Attach Build File to Project</span>
                    </button>
                  </div>

                </div>

              </form>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-500">
                <Sparkles className="w-12 h-12 mb-3 text-slate-700 animate-pulse" />
                <h3 className="text-xs font-mono uppercase tracking-widest text-slate-400 mb-1">Select a game from the left sidebar or create a new project</h3>
                <p className="text-xs text-slate-600 font-light max-w-md">You can upload game build files, update screenshots, edit Unity specs, and manage release devlogs anytime.</p>
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
